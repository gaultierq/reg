class AddPhoneNumberToUsersAndAdmins < ActiveRecord::Migration[5.2]
  def change
    add_column :users, :phone_number, :string
    add_column :admins, :phone_number, :string
  end
end
