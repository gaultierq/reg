export default {
    container: {
        flex: 1,
        marginHorizontal: 10,
        marginVertical: 5,
        borderWidth: 0.75,
        borderColor: 'white',
        borderRadius: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'black'
    },
    background: {
        flex: 1,
        width: null,
        height: null
    },
    backgroundImage: {
        resizeMode: 'cover'
    },
    transparentBackground: {
        backgroundColor: 'rgba(255, 255, 255, 0.1)'
    },
    title: {
        color: '#c28729',
        fontSize: 20,
    },
    demiTitle: {
        color: '#c28729',
        fontSize: 17,
    },
    smallTitle: {
        color: '#c28729',
        fontSize: 14,
    },
    boldTitle: {
        color: '#c28729',
        fontSize: 17,
        fontWeight: 'bold'
    },
    titleWhite: {
        color: 'white',
        fontSize: 17,
    },
    subTitle: {
        color: 'white',
    },
    buttonTitleUnderlined: {
        color: '#AA6701',
        textDecorationLine: 'underline',
        fontSize: 17,
    },
    briefInfo: {
        color: 'white',
        fontSize: 17,
    },
    verticallyCentered: {
        alignItems: 'center'
    },
    horizontallyCentered: {
        justifyContent: 'center'
    },
    center: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    flexCol: {
        flexDirection:'column'
    },
    flexRow: {
        flexDirection:'row'
    },
    flexWrap: {
        flexWrap: 'wrap'
    },
    sliderContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flex: 1,
    },
    generateButton: {
        backgroundColor: '#CB9935',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10
    },
    sendButton: {
        backgroundColor: '#CB9935',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 5,
        paddingHorizontal: 15,
    },
    selectContainer: {
        paddingHorizontal: '3%'
    },
    sliderSelected: {
        backgroundColor: '#CB9935'
    },
    sliderUnselected: {
        backgroundColor: '#443829'
    },
    sliderTrack: {
        height: 10,
        marginTop: -5
    },
    originPicto: {
        height: 40,
        width: 40,
        marginHorizontal: 3
    },
    header: {
        backgroundColor: 'black',
        borderBottomWidth: 0
    },
    breadcrumbImage: {
    },
    breadcrumbText: {
        fontSize: 10,
        marginTop: 10,
        color: 'gray',
        textAlign: 'center'
    },
    modalBackground: {
        flex: 1,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'space-around',
        backgroundColor: '#00000050'
    },
    popupBackground: {
        flex: 1,
        alignItems: 'flex-end',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        backgroundColor: '#00000050'
    },
    activityIndicatorWrapper: {
        backgroundColor: '#fafafa',
        height: 150,
        width: 175,
        borderRadius: 10,
        display: 'flex',
        alignItems: 'center'
    },
    menuTitle: {
        color: 'white',
        textAlign: 'center',
        fontSize: 15,
        flexWrap: 'wrap'
    },
    menuContainer: {
        width: 190,
        height: 165
    },
    menuButtonImage: {
        height: '50%',
        width: '50%'
    },
    absoluteCenter: {
        position: 'absolute',
        width: 190,
        height: 165,
        flex: 0,
        top: 0,
        start: 0,
        end: 0,
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center'
    },
    titleModalWrapper: {
        backgroundColor: '#100A20',
        height: '60%',
        width: '70%',
        borderRadius: 5,
        display: 'flex'
    },
    titleModalText: {
        color: 'white',
        fontSize: 17
    },
    titleModalTextBold: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 17
    },
    closeModalButton: {
        backgroundColor: '#CB9935',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 3,
        paddingHorizontal:'4%',
        paddingVertical: '1.2%'
    },
    closeModalButtonText: {
        fontSize: 17,
        color: 'white'
    },
    originModalWrapper: {
        backgroundColor: '#100A20',
        height: '75%',
        width: '70%',
        borderRadius: 5,
        display: 'flex'
    },
    originModalText: {
        color: 'white',
        fontSize: 17,
        marginLeft: '2%',
        marginRight: '5%'
    },
    originModalTextBold: {
        color: '#CB9935',
        fontWeight: 'bold',
        fontSize: 17
    },
    ingredientModalWrapper: {
        height: '60%',
        width: '60%',
    },
    percentageModalWrapper: {
        backgroundColor: '#100A20',
        height: '45%',
        width: '25%',
        borderRadius: 5,
    },
    popupWrapper: {
        height: '60%',
        width: '40%',
    },
    popupText: {
        color: 'white',
        fontSize: 17,
        textAlign: 'center',
    },
    backgroundVideo: {
        position: 'absolute',
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
    },
    briefModalWrapper: {
        backgroundColor: '#100A20',
        height: '55%',
        width: '65%',
        borderRadius: 5,
        display: 'flex'
    },
    briefModalWrapperSmallScreen: {
        backgroundColor: '#100A20',
        height: '65%',
        width: '75%',
        borderRadius: 5,
        display: 'flex'
    },
    briefModalCharacteristicsWrapper: {
        backgroundColor: '#100A20',
        height: '35%',
        width: '20%',
        borderRadius: 5,
        display: 'flex'
    },
    briefSeeMoreButton: {
        backgroundColor: '#CB9935',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 5,
        paddingHorizontal: 10,
    },
    briefContainer: {
        width: 190,
        height: 190
    },
    briefSmallContainer: {
        width: 140,
        height: 140
    },
    ActivityIndicatorStyle: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center'

    }
}