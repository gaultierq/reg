import { AppRegistry } from 'react-native';
import App from './App';
//import App from 'react-native-nfc-manager/example/App'

AppRegistry.registerComponent('technician', () => App);
