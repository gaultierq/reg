import React, { Component } from 'react';
import {
    Platform,
    StyleSheet,
    View,
    WebView,
    Alert,
    ActivityIndicator,
    Modal,
    Text,
    TouchableOpacity,
    Linking,
    BackHandler
} from 'react-native';
import Theme from './src/utils/Styles'
import NfcManager, {NdefParser} from "react-native-nfc-manager";
import { Grid, Row, Col } from 'react-native-easy-grid';
import Icon from 'react-native-vector-icons/Ionicons';
let arrayEqual = (a, b) => a && b && a.length === b.length && a.every((v, i) => v === b[i]);

export default class App extends Component {
    constructor( props ) {
        super( props );

        this.state = {
            headerColor: '#e8e5e5',
            supported: true,
            enabled: false,
            popupVisible: false,
            tag: {},
            url: '',
            canGoBack: false
        };
    }

    componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress', this._handleBackPress);
        NfcManager.isSupported()
            .then(supported => {
                this.setState({ supported });
                if (supported) {
                    this._startNfc();
                }
            })
    }

    componentWillUnmount() {
        BackHandler.removeEventListener('hardwareBackPress', this._handleBackPress);
        if (this._stateChangedSubscription) {
            this._stateChangedSubscription.remove();
        }
    }

    _handleBackPress = () => {
        if (this.state.canGoBack) {
            this._webview.goBack();
        }
        return true;
    }

    sendMessageToWebview(message: string) {
        console.log(message);
        this._webview.postMessage(message);
    }

    render() {
        return (
            <View style={{flex: 1}}>
                <Modal
                    animationType="fade"
                    transparent={true}
                    visible={this.state.popupVisible}
                    onRequestClose={() => {}}>
                    <View style={Theme.popupBackgroundNFC}>
                        <View style={{height: '25%', width: '75%', backgroundColor: 'white', borderRadius: 3}}>
                            <Grid style={{paddingHorizontal: '5%', paddingTop: '2.5%'}}>
                                <Row size={40} style={Theme.center}>
                                    <ActivityIndicator
                                        color='#009688'
                                        size='large'
                                        style={Theme.ActivityIndicatorStyle}
                                    />
                                </Row>
                                <Row size={30} style={Theme.center}>
                                    <Text style={{fontSize: 17, textAlign: 'center'}}>
                                        Placez la puce NFC au dos du téléphone
                                    </Text>
                                </Row>
                                <Row size={30} style={Theme.center}>
                                    <TouchableOpacity onPress={() => {
                                        this.setState({popupVisible: false});
                                        this._stopDetection();
                                    }}>
                                        <Text style={{color: '#009688', fontWeight: 'bold',
                                            textAlign: 'center'}}>
                                            ARRÊTER LE SCAN
                                        </Text>
                                    </TouchableOpacity>
                                </Row>
                            </Grid>
                        </View>
                    </View>
                </Modal>

                { Platform.OS === 'ios' &&
                    <View>
                        <View style={{ height: 40, backgroundColor: '#e8e5e5' }} />
                        { this.state.canGoBack &&
                            <View style={{backgroundColor: '#e8e5e5', flexDirection: 'row',}}>
                                <TouchableOpacity
                                    style={{width:'20%', flexDirection: 'row',
                                        alignItems: 'center', justifyContent: 'center'}}
                                    onPress={this._onBack.bind(this)}>
                                    <Icon name="ios-arrow-back" size={25} color='#0058a1' style={{marginRight: 15}}/>
                                    <Text style={{color: '#0058a1'}}>
                                        Retour
                                    </Text>
                                </TouchableOpacity>
                            </View>
                        }
                    </View>
                }
                <WebView ref={component => this._webview = component}
                         source={{uri: 'https://staging-reg.herokuapp.com/user'}}
                         onMessage={() => this._messageReceived() }
                         renderLoading={this._ActivityIndicatorLoadingView}
                         onLoadEnd={this._onLoadEnd}
                         onNavigationStateChange={this._onNavigationStateChange}
                         startInLoadingState={true}/>
            </View>
        );
    }

   _onBack() {
        this._webview.goBack();
    }

    _onLoadEnd = () => {
        if (Platform.OS === "android" && this._isPdf(this.state.url)) {
            Linking.canOpenURL(this.state.url).then(supported => {
                if (supported) {
                    Linking.openURL(this.state.url);
                } else {
                    console.log("Don't know how to open URI: " + this.state.url);
                }
            });
        }
    };

    _onNavigationStateChange = (navState) => {
        this.setState({
            url: navState.url,
            canGoBack: navState.canGoBack
        });
    };

    _isPdf(url) {
        return url.toLowerCase().contains(".pdf");
    }

    _ActivityIndicatorLoadingView() {
        return (
            <ActivityIndicator
                color='#009688'
                size='large'
                style={Theme.ActivityIndicatorStyle}
            />
        );
    }

    _messageReceived() {
        if (!this.state.enabled)
            this._isNFCEnabled();
        else
            this._startDetection();
    }

    _isNFCEnabled = () => {
        NfcManager.isEnabled()
            .then(enabled => {
                if (!enabled) {
                    Alert.alert(
                        'NFC désactivé',
                        'Vous devez activer le NFC pour continuer',
                        [
                            {text: 'Fermer', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
                            {text: 'Paramètres NFC', onPress: this._goToNfcSetting},
                        ],
                        {cancelable: true}
                    );
                }
                return enabled;
            })
            .catch(err => {
                console.warn(err);
            });
    };

    _startNfc() {
        NfcManager.start({
            onSessionClosedIOS: () => {
                console.log('ios session closed');
            }
        })
            .then(result => {
                console.log('start OK', result);
            })
            .catch(error => {
                console.warn('start fail', error);
                this.setState({supported: false});
            });

        if (Platform.OS === 'android') {
            NfcManager.getLaunchTagEvent()
                .then(tag => {
                    console.log('launch tag', tag);
                    if (tag) {
                        this.setState({ tag });
                    }
                })
                .catch(err => {
                    console.warn(err);
                });
            NfcManager.isEnabled()
                .then(enabled => {
                    this.setState({ enabled });
                })
                .catch(err => {
                    console.warn(err);
                });
            NfcManager.onStateChanged(
                event => {
                    if (event.state === 'on') {
                        this.setState({enabled: true});
                    } else if (event.state === 'off') {
                        this.setState({enabled: false});
                    } else if (event.state === 'turning_on') {
                        // do whatever you want
                    } else if (event.state === 'turning_off') {
                        // do whatever you want
                    }
                }
            )
                .then(sub => {
                    this._stateChangedSubscription = sub;
                    // remember to call this._stateChangedSubscription.remove()
                    // when you don't want to listen to this anymore
                })
                .catch(err => {
                    console.warn(err);
                })
        }
    }

    _goToNfcSetting = () => {
        if (this.state.supported && Platform.OS === 'android') {
            NfcManager.goToNfcSetting()
                .then(result => {
                    console.log('goToNfcSetting OK', result)
                })
                .catch(error => {
                    console.warn('goToNfcSetting fail', error)
                })
        }
    };

    _onTagDiscovered = tag => {
        console.log('Tag Discovered', tag);
        this.setState({ tag: tag, popupVisible: false });

        let text = this._parseText(tag);
        console.log(text);
        if (text !== null) {
            this.sendMessageToWebview(text);
        }
        this._stopDetection();
    };

    _parseText = (tag) => {
        const RTD_TEXT_TYPE = [0x54];
        if (tag.ndefMessage) {
            for (let message of tag.ndefMessage) {
                if (message.type && arrayEqual(RTD_TEXT_TYPE, message.type)) {
                    return NdefParser.parseText(message);
                }
            }
        }
        return null;
    };

    _startDetection = () => {
        if (this.state.enabled) {
            this.setState({popupVisible: true});
            NfcManager.registerTagEvent(this._onTagDiscovered)
                .then(result => {
                    console.log('registerTagEvent OK', result)
                })
                .catch(error => {
                    console.warn('registerTagEvent fail', error)
                })
        }
    };

    _stopDetection = () => {
        NfcManager.unregisterTagEvent()
            .then(result => {
                console.log('unregisterTagEvent OK', result)
            })
            .catch(error => {
                console.warn('unregisterTagEvent fail', error)
            })
    }
}