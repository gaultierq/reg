class AdminIndustrialUnit < ApplicationRecord
  belongs_to :admin
  belongs_to :industrial_unit
end
