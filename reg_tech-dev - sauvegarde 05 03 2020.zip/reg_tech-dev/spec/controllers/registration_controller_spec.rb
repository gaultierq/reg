require 'rails_helper'

RSpec.describe RegistrationController, type: :controller do

end
