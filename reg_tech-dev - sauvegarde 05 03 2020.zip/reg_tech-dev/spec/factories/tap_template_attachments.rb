FactoryBot.define do
  factory :tap_template_attachment do
    tap_template nil
    attachment nil
  end
end
