FactoryBot.define do
  factory :event do
    tap nil
    kind 1
  end
end
