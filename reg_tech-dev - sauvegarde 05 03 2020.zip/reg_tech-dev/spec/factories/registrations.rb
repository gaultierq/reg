FactoryBot.define do
  factory :registration do
    last_name "MyString"
    first_name "MyString"
    email "MyString"
    phone_number "MyString"
    admin nil
  end
end
