FactoryBot.define do
  factory :admin_industrial_unit do
    admin nil
    industrial_unit nil
  end
end
