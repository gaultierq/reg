FactoryBot.define do
  factory :event_attachment do
    event nil
    attachment nil
  end
end
