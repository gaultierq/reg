FactoryBot.define do
  factory :industrial_unit do
    name "MyString"
    address "MyString"
    postcode "MyString"
    city "MyString"
    country "MyString"
    latitude 1.5
    longitude 1.5
    additional_information "MyText"
    process_information "MyText"
  end
end
