FactoryBot.define do
  factory :faucet_attachment do
    faucet nil
    attachment nil
  end
end
