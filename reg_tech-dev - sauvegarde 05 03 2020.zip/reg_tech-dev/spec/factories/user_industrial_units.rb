FactoryBot.define do
  factory :user_industrial_unit do
    user nil
    industrial_unit nil
  end
end
