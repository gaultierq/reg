FactoryBot.define do
  factory :attachment do
    kind 1
  end
end
