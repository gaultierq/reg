FactoryBot.define do
  factory :admin do
    
  end
end
